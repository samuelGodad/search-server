#!/bin/bash

# Exit on error
set -e

echo "Setting up SSL certificates..."

# Create certificates directory
mkdir -p certs
cd certs

# Generate private key
openssl genrsa -out server.key 2048

# Generate CSR (Certificate Signing Request)
openssl req -new -key server.key -out server.csr -subj "/CN=localhost"

# Generate self-signed certificate
openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt

# Set proper permissions
chmod 600 server.key
chmod 644 server.crt

echo "SSL certificates generated in certs directory"
echo "Files are in: certs/"
echo "- server.key: Private key"
echo "- server.crt: Certificate" 