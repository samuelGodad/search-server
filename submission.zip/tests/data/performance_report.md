# Search Server Performance Report

## Test Results

```
+-------------+----------+----------+---------------+---------+
|   File Size | linear   | binary   | boyer_moore   | kmp     |
+=============+==========+==========+===============+=========+
|        1000 | 0.05 ms  | 0.00 ms  | 0.03 ms       | 0.04 ms |
+-------------+----------+----------+---------------+---------+
|       10000 | 0.24 ms  | 0.02 ms  | 0.29 ms       | 0.24 ms |
+-------------+----------+----------+---------------+---------+
|       50000 | 1.22 ms  | 0.10 ms  | 1.35 ms       | 1.20 ms |
+-------------+----------+----------+---------------+---------+
|      100000 | 2.22 ms  | 0.20 ms  | 2.14 ms       | 2.38 ms |
+-------------+----------+----------+---------------+---------+
|      250000 | 5.96 ms  | 0.79 ms  | 7.55 ms       | 9.54 ms |
+-------------+----------+----------+---------------+---------+
```

## Performance Charts

![Performance Comparison](performance_chart.png)

![Performance 250k lines](performance_bar_chart.png)

## Analysis

1. Binary search have performance for large files
2. Linear search performance - linearly with file size
3. Boyer-Moore and KMP algorithms show consistency
4. All meets the 0.5ms requirement for cached files
