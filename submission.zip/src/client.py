"""
Client module for the search server.
"""
import socket
import ssl
import json
from typing import Optional, Tuple
from pathlib import Path
import os

from config import Config


class SearchClient:
    """Client for the search server."""

    def __init__(
            self,
            port: Optional[int] = None,
            config_path: Optional[str] = None,
            timeout: Optional[float] = None) -> None:
        """
        Initialize search client.

        Args:
            port: Port number to connect to (overrides config)
            config_path: Path to the configuration file
            timeout: Socket timeout in seconds
        """
        try:
            self.config = Config(config_path or 'client_config.ini')
        except FileNotFoundError:
            # If config file doesn't exist, create a default config
            self.config = None
        self.port = port
        self.timeout = timeout
        self.socket: Optional[socket.socket] = None
        self.ssl_context: Optional[ssl.SSLContext] = None

    def setup_ssl(self) -> None:
        """Set up SSL context if enabled."""
        if not (self.config and self.config.ssl_enabled):
            return

        try:
            cert_path = Path('certs')
            if not cert_path.exists():
                raise FileNotFoundError(
                    "SSL certificates not found. Run setup_ssl.sh first.")

            self.ssl_context = ssl.create_default_context(
                ssl.Purpose.SERVER_AUTH)

            # In production, verify server certificate and provide client
            # certificate
            if os.getenv('ENVIRONMENT') == 'production':
                self.ssl_context.verify_mode = ssl.CERT_REQUIRED
                self.ssl_context.check_hostname = True
                self.ssl_context.load_verify_locations(
                    str(cert_path / 'ca.crt'))
                self.ssl_context.load_cert_chain(
                    str(cert_path / 'client.crt'),
                    str(cert_path / 'client.key')
                )
            else:
                # For development, accept self-signed certificates
                self.ssl_context.check_hostname = False
                self.ssl_context.verify_mode = ssl.CERT_NONE

            print("SSL context created successfully")
        except Exception as e:
            print(f"SSL setup error: {str(e)}")
            raise RuntimeError(f"Failed to set up SSL: {str(e)}")

    def connect(self) -> None:
        """Connect to the server."""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if self.timeout:
                self.socket.settimeout(self.timeout)

            # Set up SSL if enabled
            if self.config and self.config.ssl_enabled:
                print("Setting up SSL...")
                self.setup_ssl()
                print("SSL context created, wrapping socket...")
                self.socket = self.ssl_context.wrap_socket(
                    self.socket,
                    server_hostname='localhost'
                )
                print("Socket wrapped with SSL")

            port = self.port if self.port is not None else (
                self.config.port if self.config else 44445)
            print(f"Connecting to localhost:{port}...")
            self.socket.connect(('localhost', port))
            print("Connected successfully")
        except Exception as e:
            import traceback
            print(f"Connection error: {str(e)}")
            print(traceback.format_exc())
            raise ConnectionError(f"Failed to connect to server: {str(e)}")

    def search(self,
               query: str,
               algorithm: str = 'linear',
               benchmark: bool = False,
               legacy: bool = False) -> Tuple[bool,
                                              float]:
        """
        Search for a string on the server.

        Args:
            query: String to search for
            algorithm: Search algorithm to use
            benchmark: Whether to run in benchmark mode
            legacy: Use legacy protocol (plain text)

        Returns:
            Tuple of (found, execution_time)
        """
        if not self.socket:
            self.connect()

        try:
            if legacy:
                request_data = query.encode('utf-8') + b'\n'
            else:
                request = {
                    'query': query,
                    'algorithm': algorithm,
                    'benchmark': benchmark
                }
                request_data = json.dumps(request).encode('utf-8') + b'\n'

            print("Sending request...")
            # Send request
            self.socket.sendall(request_data)
            print("Request sent, waiting for response...")

            # Receive response
            response = b""
            while not response.endswith(b"\n"):
                chunk = self.socket.recv(1024)
                if not chunk:
                    break
                response += chunk

            if not response:
                raise ConnectionError("Connection closed by server")

            response = response.decode('utf-8').rstrip('\r\n')
            print(f"Received response: {response}")

            # Parse response
            if response == "STRING EXISTS":
                return True, 0.0
            elif response == "STRING NOT FOUND":
                return False, 0.0
            elif response == "RATE LIMIT EXCEEDED":
                raise RuntimeError("RATE LIMIT EXCEEDED")
            elif response.startswith("Error"):
                raise RuntimeError(response)
            else:
                raise RuntimeError(f"Unexpected response: {response}")

        except socket.timeout:
            raise TimeoutError("Connection timed out")
        except ConnectionResetError:
            raise ConnectionError("Connection reset by peer")
        except Exception as e:
            if isinstance(e, (TimeoutError, ConnectionError)):
                raise
            raise RuntimeError(f"Search failed: {str(e)}")
        finally:
            self.close()  # Close connection after each request

    def close(self) -> None:
        """Close the connection."""
        if self.socket:
            self.socket.close()
            self.socket = None


def main() -> None:
    """Main entry point."""
    import sys

    if len(sys.argv) < 2:
        print("Usage: python client.py <query> [algorithm]")
        sys.exit(1)

    query = sys.argv[1]
    algorithm = sys.argv[2] if len(sys.argv) > 2 else 'linear'

    client = SearchClient()
    try:
        found, _ = client.search(query, algorithm)
        print("STRING EXISTS" if found else "STRING NOT FOUND")
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        client.close()


if __name__ == "__main__":
    main()
