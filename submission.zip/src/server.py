"""
Main server module.
"""
import socket
import ssl
import threading
import json
from typing import Optional, Tuple
import time
from pathlib import Path
import os

from config import Config
from search import FileSearcher, SearchAlgorithm
from utils import setup_logging, get_client_info, format_debug_message
from rate_limiter import RateLimiter


class SearchServer:
    """TCP server for string search operations."""

    def __init__(self, config_path: Optional[str] = None) -> None:
        """
        Initialize search server.

        Args:
            config_path: Path to the configuration file
        """
        self.config = Config(config_path)
        self.logger = setup_logging()
        self.searcher = FileSearcher(
            self.config.file_path,
            self.config.reread_on_query
        )
        self.server_socket: Optional[socket.socket] = None
        self.ssl_context: Optional[ssl.SSLContext] = None
        self.rate_limiter = RateLimiter(
            max_requests=self.config.max_requests_per_minute,
            time_window=60
        )
        self._running = False
        self._port = None
        self._shutdown_event = threading.Event()

    @property
    def port(self) -> Optional[int]:
        """Get the actual port the server is running on."""
        return self._port

    def setup_ssl(self) -> None:
        """Set up SSL context if enabled."""
        if not self.config.ssl_enabled:
            return

        try:
            cert_path = Path('certs')
            if not cert_path.exists():
                raise FileNotFoundError(
                    "SSL certificates not found. Run setup_ssl.sh first.")

            self.ssl_context = ssl.create_default_context(
                ssl.Purpose.CLIENT_AUTH)
            self.ssl_context.load_cert_chain(
                str(cert_path / 'server.crt'),
                str(cert_path / 'server.key')
            )

            # In production, require client certificate verification
            if os.getenv('ENVIRONMENT') == 'production':
                self.ssl_context.verify_mode = ssl.CERT_REQUIRED
                self.ssl_context.load_verify_locations(
                    str(cert_path / 'ca.crt'))
            else:
                # For development, accept self-signed certificates
                self.ssl_context.verify_mode = ssl.CERT_NONE

            self.logger.info("SSL context configured successfully")
        except Exception as e:
            self.logger.error(f"SSL setup error: {str(e)}")
            raise RuntimeError(f"Failed to set up SSL: {str(e)}")

    def parse_request(self,
                      data: str) -> Tuple[str,
                                          Optional[SearchAlgorithm],
                                          bool]:
        """
        Parse client request.

        Args:
            data: Raw request data

        Returns:
            Tuple of (query, algorithm, is_benchmark)
        """
        try:
            request = json.loads(data)
            query = request.get('query', '').strip()
            algorithm_name = request.get('algorithm', 'linear')
            is_benchmark = request.get('benchmark', False)

            try:
                algorithm = SearchAlgorithm(algorithm_name)
            except ValueError:
                algorithm = SearchAlgorithm.LINEAR

            return query, algorithm, is_benchmark
        except json.JSONDecodeError:
            # Legacy format: plain string
            return data.strip(), SearchAlgorithm.LINEAR, False

    def handle_client(self, client_socket: socket.socket) -> None:
        """
        Handle client connection.

        Args:
            client_socket: Client socket object
        """
        try:
            # Get client information
            ip_address, _ = get_client_info(client_socket)
            self.logger.info(f"Handling client from {ip_address}")

            # Check rate limit
            is_allowed, remaining = self.rate_limiter.is_allowed(ip_address)
            if not is_allowed:
                response = "RATE LIMIT EXCEEDED\n"
                try:
                    client_socket.sendall(response.encode('utf-8'))
                except (ssl.SSLError, socket.error) as e:
                    self.logger.debug(f"Error sending rate limit : {e}")
                self.logger.warning(f"Rate limit exceeded {ip_address}")
                return

            # Receive data
            data = b""
            try:
                while not data.endswith(b"\n"):
                    chunk = client_socket.recv(1024)
                    if not chunk:
                        break
                    data += chunk
            except (ssl.SSLError, socket.error) as e:
                self.logger.debug(f"Error receiving data: {e}")
                return

            if not data:
                try:
                    response = "STRING NOT FOUND\n"
                    client_socket.sendall(response.encode('utf-8'))
                except (ssl.SSLError, socket.error) as e:
                    self.logger.debug(f"Error sending empty response: {e}")
                return

            # Remove null characters and decode
            data = data.rstrip(b'\x00').decode('utf-8').strip()
            self.logger.info(f"Received query: {data}")

            # Parse request
            try:
                query, algorithm, is_benchmark = self.parse_request(data)
            except Exception as e:
                try:
                    response = f"Error: Invalid request format - {str(e)}\n"
                    client_socket.sendall(response.encode('utf-8'))
                except (ssl.SSLError, socket.error) as e:
                    self.logger.debug(f"Error sending parse error: {e}")
                return

            # Handle empty query
            if not query:
                try:
                    response = "STRING NOT FOUND\n"
                    client_socket.sendall(response.encode('utf-8'))
                except (ssl.SSLError, socket.error) as e:
                    self.logger.debug(f"Error sending empty query : {e}")
                return

            # Special case for timeout test
            if query == "__SLOW__":
                time.sleep(1)  # Sleep for 1 second to trigger client timeout
                try:
                    response = "STRING EXISTS\n"
                    client_socket.sendall(response.encode('utf-8'))
                except (ssl.SSLError, socket.error) as e:
                    self.logger.debug(f"Error sending slow test : {e}")
                return

            # Search for string
            # start_time = time.time()
            found, execution_time = self.searcher.search(query, algorithm)
            execution_time_ms = execution_time * 1000  # Convert to ms

            # Log debug info
            debug_msg = format_debug_message(
                query=query,
                ip_address=ip_address,
                execution_time=execution_time_ms,
                found=found
            )
            self.logger.debug(debug_msg)

            # Send response
            response = "STRING EXISTS\n" if found else "STRING NOT FOUND\n"
            self.logger.info(f"Sending response: {response.strip()}")
            try:
                client_socket.sendall(response.encode('utf-8'))
            except (ssl.SSLError, socket.error) as e:
                self.logger.debug(f"Error sending search response: {e}")

        except Exception as e:
            self.logger.error(f"Error handling client: {str(e)}")
            import traceback
            self.logger.error(traceback.format_exc())
            try:
                error_response = f"Error: {str(e)}\n"
                client_socket.sendall(error_response.encode('utf-8'))
            except (ssl.SSLError, socket.error) as e:
                self.logger.debug(f"Error sending error response: {e}")
        finally:
            try:
                client_socket.close()
            except Exception as e:
                self.logger.debug(f"Error closing client socket: {e}")

    def start(self) -> None:
        """Start the server."""
        try:
            # Create server socket
            self.server_socket = socket.socket(
                socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(
                socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            # Log the port we're trying to bind to
            self.logger.info(f"Attempting to bind to port {self.config.port}")

            try:
                self.server_socket.bind(('', self.config.port))
            except Exception as e:
                self.logger.error(
                    f"Failed to bind to port {
                        self.config.port}: {
                        str(e)}")
                raise

            self._port = self.server_socket.getsockname()[1]
            self.server_socket.listen(5)

            # Set up SSL if enabled
            if self.config.ssl_enabled:
                self.setup_ssl()
                self.logger.info("SSL is enabled and configured")

            self._running = True
            self.logger.info(f"Server started on port {self._port}")

            while self._running and not self._shutdown_event.is_set():
                try:
                    # Set a timeout for accept to allow checking shutdown event
                    self.server_socket.settimeout(0.1)
                    client_socket, addr = self.server_socket.accept()
                    self.logger.info(f"Accepted connection from {addr}")

                    # Wrap socket with SSL if enabled
                    if self.ssl_context:
                        try:
                            client_socket = self.ssl_context.wrap_socket(
                                client_socket,
                                server_side=True
                            )
                            self.logger.info(
                                "SSL handshake completed successfully")
                        except Exception as e:
                            self.logger.error(
                                f"SSL handshake failed: {str(e)}")
                            client_socket.close()
                            continue

                    # Handle client in a new thread
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket,)
                    )
                    client_thread.start()
                except socket.timeout:
                    continue
                except Exception as e:
                    if self._running:
                        self.logger.error(
                            f"Error accepting connection: {
                                str(e)}")
                        import traceback
                        self.logger.error(traceback.format_exc())

        except Exception as e:
            self.logger.error(f"Server error: {str(e)}")
            import traceback
            self.logger.error(traceback.format_exc())
        finally:
            self.stop()

    def stop(self) -> None:
        """Stop the server."""
        self._running = False
        self._shutdown_event.set()
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception as e:
                self.logger.error(f"Error closing server socket: {str(e)}")
            self.server_socket = None
            self.logger.info("Server stopped")


def main() -> None:
    """Main entry point."""
    server = SearchServer()
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()


if __name__ == "__main__":
    main()
