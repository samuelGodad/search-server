#!/bin/bash

# Activate virtual environment
source venv/bin/activate

# Run performance tests
python tests/