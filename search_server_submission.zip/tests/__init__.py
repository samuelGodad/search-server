"""
Test package for search server.
"""
